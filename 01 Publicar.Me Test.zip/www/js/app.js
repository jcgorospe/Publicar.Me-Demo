app.constant("Config", {
  "WebUrl": "http://publicar.me/test/api/",
  "AppName" : "Publicar.Me Demo",
  "AndroidAppUrl" : "https://play.google.com/store/apps/details?id=com.myspecialgames.advanced2048game",
  "ErrorMessage" : "No Más Resultados"
})
// config contact
app.constant("ConfigContact", {
  "EmailId": "jcgorospe@publicar.me",
  "ContactSubject": "Contacto"
})
// config admon
// App ID: ca-app-pub-7574119380219968~6275870805
app.constant("ConfigAdmob", {
  "interstitial": "ca-app-pub-7574119380219968/7752604008",
  "banner": "ca-app-pub-7574119380219968/9229337200"
})
// color variations
app.constant("Color", {
  "AppColor": "light", //light, stable, positive, calm, balanced, energized, assertive, royal, dark
})
// push notification
app.constant("PushNoti", {
  "senderID": "senderID",
})

